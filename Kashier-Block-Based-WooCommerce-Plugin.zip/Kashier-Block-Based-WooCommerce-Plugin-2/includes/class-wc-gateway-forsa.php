<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Gateway_Kashier_Forsa class.
 *
 * @extends Kashier_Gateway
 */
class WC_Gateway_Kashier_Forsa extends Kashier_Gateway
{
    protected $_code = 'forsa';
    public $name = 'forsa';
    public $icons = ['forsa.png'];

}
