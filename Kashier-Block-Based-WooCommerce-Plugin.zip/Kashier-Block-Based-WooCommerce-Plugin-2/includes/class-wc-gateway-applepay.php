<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Gateway_Kashier_Applepay class.
 *
 * Apple Pay on our own WooCommerce pay page using the Kashier SDK:
 * Place order creates the Kashier session, then the customer lands on the
 * order-pay page where Kashier's SDK shows the Apple Pay button for that
 * session. Apple only opens the payment sheet from a real tap on that button.
 *
 * @extends Kashier_Gateway
 */
class WC_Gateway_Kashier_Applepay extends Kashier_Gateway
{
    protected $_code = 'applepay';
    public $name = 'applepay';
    public $icons = ['applepay.svg'];
    public $admin_icon = 'applepay.svg';

    protected static $hooks_added = false;

    public function __construct()
    {
        parent::__construct();
        // Title used by the block checkout (respects the title saved in the method's settings)
        $this->block_title = $this->title;

        if (!self::$hooks_added) {
            self::$hooks_added = true;
            add_action('wp_ajax_kashier_applepay_verify', [$this, 'ajax_verify_payment']);
            add_action('wp_ajax_nopriv_kashier_applepay_verify', [$this, 'ajax_verify_payment']);
        }
    }

    public function init_form_fields()
    {
        parent::init_form_fields();

        // Domain verification file Kashier sends after registering the domain with Apple.
        $this->form_fields['domain_file'] = array(
            'title'       => __('Apple Pay domain file', 'woocommerce-gateway-kashier'),
            'type'        => 'textarea',
            'description' => __('Paste the contents of the domain-association file Kashier sent you. It is served at /.well-known/apple-developer-merchantid-domain-association (and the same path ending in .txt).', 'woocommerce-gateway-kashier'),
            'default'     => '',
            'css'         => 'min-height:120px;font-family:monospace;',
            'desc_tip'    => true,
        );
    }

    /**
     * Place order: create the Kashier session, keep its id, and send the customer
     * to the WooCommerce pay page (not to Kashier's hosted page).
     */
    public function process_payment($order_id, $retry = true, $force_save_source = false, $previous_error = false)
    {
        $order = wc_get_order($order_id);

        WC_Kashier_Logger::addLog("Info: Begin Apple Pay payment for order $order_id for the amount of {$order->get_total()}");

        $result = $this->create_kashier_session($order);
        $session_id = $this->extract_session_id($result);

        if ($session_id === '') {
            $error_message = isset($result['error']['message'])
                ? $result['error']['message']
                : __('Payment session creation failed.', 'woocommerce-gateway-kashier');
            WC_Kashier_Logger::addLog('Apple Pay: no session id in response');
            wc_add_notice($error_message, 'error');
            return array(
                'result' => 'failure',
                'messages' => array($error_message),
            );
        }

        $order->update_meta_data('_kashier_session_id', $session_id);
        $order->save();

        return [
            'result' => 'success',
            'redirect' => $order->get_checkout_payment_url(true),
        ];
    }

    /**
     * Pay page (hook woocommerce_receipt_kashier_applepay): show the Kashier SDK
     * Apple Pay button for the session created in process_payment().
     */
    public function kashier_receipt_page($order_id)
    {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $session_id = (string) $order->get_meta('_kashier_session_id', true);
        if ($session_id === '') {
            echo '<p>' . esc_html__('We could not start the payment. Please go back and try again.', 'woocommerce-gateway-kashier') . '</p>';
            echo '<p><a class="button" href="' . esc_url(wc_get_checkout_url()) . '">' . esc_html__('Back to checkout', 'woocommerce-gateway-kashier') . '</a></p>';
            return;
        }

        $language = substr(get_bloginfo('language'), 0, 2) == 'ar' ? 'ar' : 'en';

        wp_enqueue_script('kashier-sdk', 'https://payments.kashier.io/kashier-sdk.js', [], null, true);
        wp_enqueue_script(
            'kashier-applepay',
            plugins_url('assets/js/kashier-applepay.js', WC_KASHIER_MAIN_FILE),
            ['kashier-sdk'],
            WC_KASHIER_VERSION,
            true
        );
        wp_localize_script('kashier-applepay', 'kashierApplepay', [
            'mode'        => $this->testmode ? 'test' : 'live',
            'sessionId'   => $session_id,
            'locale'      => $language,
            'returnUrl'   => $this->get_return_url($order),
            'checkoutUrl' => wc_get_checkout_url(),
            'ajaxUrl'     => admin_url('admin-ajax.php'),
            'nonce'       => wp_create_nonce('kashier_applepay_verify_' . $order->get_id()),
            'orderId'     => $order->get_id(),
            'orderKey'    => $order->get_order_key(),
            'i18n'        => [
                'unsupported' => __('Apple Pay is not available on this device or browser. Please go back and choose another payment method.', 'woocommerce-gateway-kashier'),
                'failed'      => __('The payment was not completed.', 'woocommerce-gateway-kashier'),
                'retry'       => __('Back to checkout', 'woocommerce-gateway-kashier'),
            ],
        ]);

        // Only the Apple Pay section is styled here. The page, theme, header and footer render
        // exactly as the theme/WooCommerce output them (no page-level overrides).
        // clear:both + flow-root: the theme floats the order details (order number, date, total...)
        // to the left; without this the hint text wraps around them instead of sitting above the button.
        echo '<div class="kashier-applepay-page" style="clear:both;display:flow-root;text-align:center;padding:24px 0">';
        echo '<div style="width:100%;max-width:420px;margin:0 auto">';
        echo '<p class="kashier-applepay-hint" style="margin:0 0 20px;text-align:center;text-wrap:balance">' . esc_html__('Tap the Apple Pay button below to pay.', 'woocommerce-gateway-kashier') . '</p>';
        echo '<div id="kashier-sdk-id" style="min-height:56px"></div>';
        echo '<div id="kashier-success-id" style="margin-top:16px"></div>';
        echo '<div id="kashier-failure-id" style="margin-top:16px"></div>';
        echo '<p style="margin:24px 0 0"><a href="' . esc_url(wc_get_checkout_url()) . '">' . esc_html__('Back to checkout', 'woocommerce-gateway-kashier') . '</a></p>';
        echo '</div>';
        echo '</div>';
    }

    /**
     * Server-side confirmation after the SDK reports success: ask Kashier for the
     * session's payment and complete the order if it was paid. The webhook does the
     * same, so whichever arrives first wins and the other is a no-op.
     */
    public function ajax_verify_payment()
    {
        $order_id = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
        $order = $order_id ? wc_get_order($order_id) : false;

        if (!$order
            || !isset($_POST['nonce'], $_POST['key'])
            || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'kashier_applepay_verify_' . $order_id)
            || !$order->key_is_valid(sanitize_text_field(wp_unslash($_POST['key'])))
            || $order->get_payment_method() !== $this->id) {
            wp_send_json_error(['message' => 'invalid request'], 400);
        }

        if ($order->is_paid()) {
            wp_send_json_success(['status' => 'paid']);
        }

        $session_id = (string) $order->get_meta('_kashier_session_id', true);
        if ($session_id === '') {
            wp_send_json_error(['message' => 'no session'], 400);
        }

        $base = $this->testmode ? 'https://test-api.kashier.io' : 'https://api.kashier.io';
        $response = wp_remote_get($base . '/v3/payment/sessions/' . rawurlencode($session_id) . '/payment', [
            'headers' => ['Authorization' => $this->secret_key],
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            WC_Kashier_Logger::addLog('Apple Pay verify error: ' . $response->get_error_message());
            wp_send_json_success(['status' => 'pending']);
        }

        $body = wp_remote_retrieve_body($response);
        WC_Kashier_Logger::addLog('Apple Pay verify response: ' . $body);
        $data = json_decode($body, true);

        $status = '';
        $transaction_id = '';
        $kashier_order_id = '';
        if (is_array($data)) {
            foreach ([$data, $data['response'] ?? [], $data['data'] ?? []] as $bucket) {
                if (!is_array($bucket)) {
                    continue;
                }
                // Kashier's own order id: needed later to refund through the API
                foreach (['kashierOrderId', 'orderId'] as $key) {
                    if ($kashier_order_id === '' && !empty($bucket[$key]) && is_string($bucket[$key])) {
                        $kashier_order_id = $bucket[$key];
                    }
                }
                foreach (['status', 'paymentStatus', 'result'] as $key) {
                    if ($status === '' && !empty($bucket[$key]) && is_string($bucket[$key])) {
                        $status = strtoupper($bucket[$key]);
                    }
                }
                if ($transaction_id === '' && !empty($bucket['transactionId']) && is_string($bucket['transactionId'])) {
                    $transaction_id = $bucket['transactionId'];
                }
            }
        }

        if (in_array($status, ['SUCCESS', 'APPROVED', 'PAID', 'CAPTURED'], true)) {
            if ($kashier_order_id !== '' && !$order->get_meta('kashierOrderId', true)) {
                $order->update_meta_data('kashierOrderId', wc_clean($kashier_order_id));
            }
            $order->payment_complete($transaction_id);
            $order->add_order_note(sprintf('Apple Pay payment confirmed with Kashier. TX: %s', $transaction_id));
            wp_send_json_success(['status' => 'paid']);
        }

        // Not confirmed yet: the webhook will complete the order.
        wp_send_json_success(['status' => 'pending']);
    }
}
