<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Gateway_Kashier_Tru class.
 *
 * @extends Kashier_Gateway
 */
class WC_Gateway_Kashier_Tru extends Kashier_Gateway
{
    protected $_code = 'tru';
    public $name = 'tru';
    public $icons = ['tru.png'];

}
