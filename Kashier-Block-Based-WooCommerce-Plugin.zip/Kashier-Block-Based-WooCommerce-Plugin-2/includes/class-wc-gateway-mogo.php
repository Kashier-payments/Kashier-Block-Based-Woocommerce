<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Gateway_Kashier_Mogo class.
 *
 * @extends Kashier_Gateway
 */
class WC_Gateway_Kashier_Mogo extends Kashier_Gateway
{
    protected $_code = 'mogo';
    public $name = 'mogo';
    public $icons = ['mogo.svg'];

}
