<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Gateway_Kashier_Bnpl class.
 *
 * One "Buy Now, Pay Later" method that replaces the separate valU, Souhoola,
 * Aman, Contact, Tru, Mogo and Forsa methods at checkout. Kashier's hosted
 * page lets the customer pick the provider.
 *
 * @extends Kashier_Gateway
 */
class WC_Gateway_Kashier_Bnpl extends Kashier_Gateway
{
    protected $_code = 'bnpl';
    public $name = 'bnpl';
    // Provider logos, in display order (checkout and the admin payments list)
    const PROVIDER_ICONS = ['valu.svg', 'souhoola.svg', 'aman.svg', 'contact_now.svg', 'tru.png', 'mogo.svg', 'forsa.png'];
    public $icons = self::PROVIDER_ICONS;
    // Logo in the WooCommerce admin payment methods list: "BNPL" on #20187b
    public $admin_icon = 'bnpl-logo.svg';

    public function __construct()
    {
        parent::__construct();
        // Title used by the block checkout (respects the title saved in the method's settings)
        $this->block_title = $this->title;
    }
}
