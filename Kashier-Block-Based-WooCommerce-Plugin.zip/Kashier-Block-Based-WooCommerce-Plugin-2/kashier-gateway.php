<?php
/**
 * Plugin Name: WooCommerce Kashier Gateway 
 * Description: Accept online payments on your store.
 * Author: Kashier
 * Author URI: https://kashier.io/
 * Version: 2.1.45
 * Requires at least: 6.0
 * Tested up to: 6.9.4
 * WC requires at least: 8.0.0
 * WC tested up to: 10.6.1
 * Text Domain: woocommerce-gateway-kashier
 * Domain Path: /languages
 * Plugin URI: https://github.com/Kashier-payments/Kashier-WooCommerce-Plugin/
 *
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}



add_action('plugins_loaded', 'woocommerce_kashier_gateway_init', 0);

function woocommerce_kashier_gateway_init()
{
    if (!class_exists('WC_Payment_Gateway'))
        return;
    add_filter('woocommerce_subscriptions_is_duplicate_site', '__return_false');
    load_plugin_textdomain('woocommerce-gateway-kashier', false, plugin_basename(__DIR__) . '/languages');
    if (!class_exists('WooCommerce')) {

        add_action('admin_notices', 'woocommerce_kashier_missing_wc_notice');

        return;
    }




    if (!class_exists('WC_Kashier')):
        /**
         * Required minimums and constants
         */
        define('WC_KASHIER_VERSION', '2.1.45');
        define('WC_KASHIER_MIN_PHP_VER', '7.4.0');
        define('WC_KASHIER_MIN_WC_VER', '8.0.0');
        define('WC_KASHIER_MAIN_FILE', __FILE__);
        define('WC_KASHIER_PLUGIN_URL', untrailingslashit(plugins_url(basename(plugin_dir_path(__FILE__)), basename(__FILE__))));
        define('WC_KASHIER_PLUGIN_PATH', untrailingslashit(plugin_dir_path(__FILE__)));

        class WC_Kashier
        {
            /**
             * @var WC_Kashier $instance Singleton The reference the *Singleton* instance of this class
             */
            private static $instance;

            /**
             * Returns the *Singleton* instance of this class.
             *
             * @return WC_Kashier The *Singleton* instance.
             */
            public static function get_instance()
            {
                if (null === self::$instance) {
                    self::$instance = new self();
                }

                return self::$instance;
            }

            /**
             * Private clone method to prevent cloning of the instance of the
             * *Singleton* instance.
             *
             * @return void
             */
            private function __clone()
            {
            }

            /**
             *
             * @return void
             */
            public function __wakeup()
            {
            }

            /**
             * Protected constructor to prevent creating a new instance of the
             * *Singleton* via the `new` operator from outside of this class.
             */
            private function __construct()
            {
                add_action('admin_init', array($this, 'install'));
                $this->init();
            }

            /**
             * Init the plugin after plugins_loaded so environment variables are set.
             */
            public function init()
            {
                require_once __DIR__ . '/lib/vendor/autoload.php';
                require_once __DIR__ . '/includes/class-wc-kashier-exception.php';
                require_once __DIR__ . '/includes/class-wc-kashier-logger-factory.php';
                require_once __DIR__ . '/includes/class-wc-kashier-logger.php';
                require_once __DIR__ . '/includes/class-wc-kashier-helper.php';
                require_once __DIR__ . '/class-kashier-gateway.php';
                require_once __DIR__ . '/includes/class-wc-gateway-card.php';
                require_once __DIR__ . '/includes/class-wc-gateway-installment.php';
                require_once __DIR__ . '/includes/class-wc-gateway-valu.php';
                require_once __DIR__ . '/includes/class-wc-gateway-souhoola.php';
                require_once __DIR__ . '/includes/class-wc-gateway-aman.php';
                require_once __DIR__ . '/includes/class-wc-gateway-contact.php';
                require_once __DIR__ . '/includes/class-wc-gateway-mogo.php';
                require_once __DIR__ . '/includes/class-wc-gateway-forsa.php';
                require_once __DIR__ . '/includes/class-wc-gateway-bnpl.php';
                require_once __DIR__ . '/includes/class-wc-gateway-applepay.php';
                require_once __DIR__ . '/includes/class-wc-gateway-tru.php';
                require_once __DIR__ . '/includes/class-wc-gateway-wallet.php';


                add_filter('woocommerce_payment_gateways', array($this, 'add_gateways'));
                // add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'plugin_action_links'));
            }

            /**
             * Updates the plugin version in db
             */
            public function update_plugin_version()
            {
                delete_option('wc_kashier_version');
                update_option('wc_kashier_version', WC_KASHIER_VERSION);
            }

            /**
             * Handles upgrade routines.
             */
            public function install()
            {
                if (!is_plugin_active(plugin_basename(__FILE__))) {
                    return;
                }

                if (!defined('IFRAME_REQUEST') && (WC_KASHIER_VERSION !== get_option('wc_kashier_version'))) {
                    do_action('woocommerce_kashier_updated');

                    if (!defined('WC_KASHIER_INSTALLING')) {
                        define('WC_KASHIER_INSTALLING', true);
                    }

                    $this->update_plugin_version();
                }
            }

            /**
             * Adds plugin action links.
             */
            // public function plugin_action_links($links)
            // {
            //     $plugin_links = array(
            //         '<a href="admin.php?page=wc-settings&tab=checkout&section=kashier">' . esc_html__('Settings', 'woocommerce-gateway-kashier') . '</a>'
            //     );

            //     return array_merge($plugin_links, $links);
            // }

            /**
             * Add the gateways to WooCommerce.
             */
            public function add_gateways($methods)
            {
                $methods[] = 'WC_Gateway_Kashier_Card';
                $methods[] = 'WC_Gateway_Kashier_Installment';
                $methods[] = 'WC_Gateway_Kashier_Valu';
                $methods[] = 'WC_Gateway_Kashier_Souhoola';
                $methods[] = 'WC_Gateway_Kashier_Aman';
                $methods[] = 'WC_Gateway_Kashier_Contact';
                $methods[] = 'WC_Gateway_Kashier_Mogo';
                $methods[] = 'WC_Gateway_Kashier_Forsa';
                $methods[] = 'WC_Gateway_Kashier_Bnpl';
                $methods[] = 'WC_Gateway_Kashier_Applepay';
                $methods[] = 'WC_Gateway_Kashier_Tru';
                $methods[] = 'WC_Gateway_Kashier_Wallet';



                return $methods;
            }

            /**
             * Modifies the order of the gateways displayed in admin.
             */
            public function filter_gateway_order_admin($sections)
            {
                unset($sections['kashier']);

                $sections['kashier'] = 'Kashier';

                return $sections;
            }
        }

        WC_Kashier::get_instance();
    endif;

}

// add_action( 'before_woocommerce_init', function() {
//     if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
//     }
// } );

add_action('before_woocommerce_init', function () {

    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);

    }

});
add_action('woocommerce_blocks_loaded', function () {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);

    }
});

// Apple Pay domain verification: serve the file Kashier gave us (saved in the Apple Pay method's
// settings) at /.well-known/apple-developer-merchantid-domain-association and the .txt variant.
add_action('init', function () {
    $path = isset($_SERVER['REQUEST_URI']) ? wp_parse_url(wp_unslash($_SERVER['REQUEST_URI']), PHP_URL_PATH) : '';
    if (!is_string($path)) {
        return;
    }
    $path = untrailingslashit($path);
    $home_path = untrailingslashit((string) wp_parse_url(home_url('/'), PHP_URL_PATH));
    $wanted = $home_path . '/.well-known/apple-developer-merchantid-domain-association';
    if ($path !== $wanted && $path !== $wanted . '.txt') {
        return;
    }

    $settings = get_option('woocommerce_kashier_applepay_settings', []);
    $content = is_array($settings) && !empty($settings['domain_file']) ? (string) $settings['domain_file'] : '';
    if (trim($content) === '') {
        return; // nothing saved: let the request continue (404 or a real file on disk)
    }

    status_header(200);
    nocache_headers();
    header('Content-Type: text/plain; charset=utf-8');
    echo trim($content);
    exit;
}, 1);

// Settings > Payments: show the BNPL provider logos under the "Buy Now, Pay Later" description
add_action('admin_enqueue_scripts', function () {
    if (!isset($_GET['page'], $_GET['tab']) || $_GET['page'] !== 'wc-settings' || $_GET['tab'] !== 'checkout') {
        return;
    }
    if (!class_exists('WC_Gateway_Kashier_Bnpl')) {
        return;
    }

    $base = untrailingslashit(plugins_url('assets/images', __FILE__));
    $logos = [];
    foreach (WC_Gateway_Kashier_Bnpl::PROVIDER_ICONS as $icon) {
        $logos[] = $base . '/' . $icon . '?ver=' . WC_KASHIER_VERSION;
    }

    wp_enqueue_script(
        'kashier-admin-list',
        plugins_url('assets/js/kashier-admin-list.js', __FILE__),
        [],
        WC_KASHIER_VERSION,
        true
    );
    wp_localize_script('kashier-admin-list', 'kashierBnplAdminList', [
        'rowId' => 'kashier_bnpl',
        'logos' => $logos,
    ]);
});
// Declare compatibility with WooCommerce Checkout Blocks
// function declare_cart_checkout_blocks_compatibility() {
//     if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
//         \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
//     }
// }

// add_action('before_woocommerce_init', 'declare_cart_checkout_blocks_compatibility');

// Register the custom payment gateway for WooCommerce Checkout Blocks
add_action('woocommerce_blocks_loaded', 'register_kashier_gateway_block');

function register_kashier_gateway_block()
{
    if (!class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType'))
        return;
    require_once plugin_dir_path(__FILE__) . '/blocks/base-gatway-block.php';


    $gateway_files = glob(plugin_dir_path(__FILE__) . '/blocks/*-gateway.php');

    foreach ($gateway_files as $file) {
        require_once $file;
    }
    // if ( class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) && class_exists( 'Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry' ) ) {

    //     $gateway_classes = [
    //         'Kashier_Gateway_Aman_Blocks',
    //         'Kashier_Gateway_Card_Blocks',
    //         'Kashier_Gateway_Wallet_Blocks',
    //         'Kashier_Gateway_Bank_Installments_Blocks',
    //         'Kashier_Gateway_Valu_Blocks',
    //         'Kashier_Gateway_Souhoola_Blocks'
    //     ];

    //     add_action(
    //             'woocommerce_blocks_payment_method_type_registration',
    //             function (Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry)  {
    //                 $container = Automattic\WooCommerce\Blocks\Package::container();
    //                 $container->register(
    //                     'Kashier_Gateway_Card_Blocks',
    //                     function ()  {
    //                         return new Kashier_Gateway_Card_Blocks();
    //                     }
    //                 );
    //                 $payment_method_registry->register($container->get('Kashier_Gateway_Card_Blocks'));
    //             }
    //         );

    //     foreach ($gateway_classes as $gateway_class) {
    //         add_action(
    //             'woocommerce_blocks_payment_method_type_registration',
    //             function (Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry) use ($gateway_class) {
    //                 $container = Automattic\WooCommerce\Blocks\Package::container();
    //                 $container->register(
    //                     $gateway_class,
    //                     function () use ($gateway_class) {
    //                         return new $gateway_class();
    //                     }
    //                 );
    //                 $payment_method_registry->register($container->get($gateway_class));
    //             }
    //         );
    //     }
    // }

    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function (Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry) {
            $payment_method_registry->register(new Kashier_Gateway_Card_Blocks());
            $payment_method_registry->register(new Kashier_Gateway_Wallet_Blocks());
            $payment_method_registry->register(new Kashier_Gateway_Aman_Blocks());
            $payment_method_registry->register(new Kashier_Gateway_Contact_Blocks());
            $payment_method_registry->register(new Kashier_Gateway_Valu_Blocks());
            $payment_method_registry->register(new Kashier_Gateway_Souhoola_Blocks());
            $payment_method_registry->register(new Kashier_Gateway_Mogo_Blocks());
            $payment_method_registry->register(new Kashier_Gateway_Forsa_Blocks());
            $payment_method_registry->register(new Kashier_Gateway_Bnpl_Blocks());
            $payment_method_registry->register(new Kashier_Gateway_Applepay_Blocks());
            $payment_method_registry->register(new Kashier_Gateway_Tru_Blocks());
            $payment_method_registry->register(new Kashier_Gateway_Bank_Installments_Blocks());
        }
    );

}









