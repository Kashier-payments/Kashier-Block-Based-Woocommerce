<?php
class Kashier_Gateway_Forsa_Blocks extends Base_Gateway_Blocks {
    protected $gateway_script = 'kashier_gateway-forsa-blocks-integration';
    protected $name = 'kashier_forsa';
    protected function create_gateway_instance() {
        return new WC_Gateway_Kashier_Forsa();
    }
}
