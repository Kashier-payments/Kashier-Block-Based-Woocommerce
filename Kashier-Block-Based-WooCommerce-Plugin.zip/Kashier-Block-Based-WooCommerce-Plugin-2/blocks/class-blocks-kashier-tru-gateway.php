<?php
class Kashier_Gateway_Tru_Blocks extends Base_Gateway_Blocks {
    protected $gateway_script = 'kashier_gateway-tru-blocks-integration';
    protected $name = 'kashier_tru';
    protected function create_gateway_instance() {
        return new WC_Gateway_Kashier_Tru();
    }
}
