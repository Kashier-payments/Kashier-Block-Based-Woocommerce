<?php
class Kashier_Gateway_Mogo_Blocks extends Base_Gateway_Blocks {
    protected $gateway_script = 'kashier_gateway-mogo-blocks-integration';
    protected $name = 'kashier_mogo';
    protected function create_gateway_instance() {
        return new WC_Gateway_Kashier_Mogo();
    }
}
