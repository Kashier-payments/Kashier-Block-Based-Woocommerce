<?php
class Kashier_Gateway_Applepay_Blocks extends Base_Gateway_Blocks {
    protected $gateway_script = 'kashier_gateway-applepay-blocks-integration';
    protected $name = 'kashier_applepay';
    protected function create_gateway_instance() {
        return new WC_Gateway_Kashier_Applepay();
    }
}
