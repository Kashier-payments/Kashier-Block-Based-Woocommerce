<?php
use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

abstract class Base_Gateway_Blocks extends AbstractPaymentMethodType {
    protected $gateway;
    protected $gateway_id;
    protected $gateway_name;
    protected $gateway_script;

    public function initialize() {
        $this->gateway = $this->create_gateway_instance();
    }

    abstract protected function create_gateway_instance();

    /**
     * Block checkout title (translatable). Same English text as before.
     */
    protected function get_block_title()
    {
        $titles = [
            'card'              => __('Card', 'woocommerce-gateway-kashier'),
            'wallet'            => __('Wallet', 'woocommerce-gateway-kashier'),
            'bank_installments' => __('Bank Installments', 'woocommerce-gateway-kashier'),
            'valu'              => __('Valu', 'woocommerce-gateway-kashier'),
            'souhoola'          => __('Souhoola', 'woocommerce-gateway-kashier'),
            'aman'              => __('Aman', 'woocommerce-gateway-kashier'),
            'contact'           => __('Contact Now', 'woocommerce-gateway-kashier'),
            'mogo'              => __('Mogo', 'woocommerce-gateway-kashier'),
            'forsa'             => __('Forsa', 'woocommerce-gateway-kashier'),
            'tru'               => __('Tru', 'woocommerce-gateway-kashier'),
        ];

        $name = $this->gateway->name;

        return isset($titles[$name]) ? $titles[$name] : ucwords(str_replace('_', ' ', $name));
    }

    public function get_payment_method_script_handles() {
        // Stable version so the browser can cache the scripts (a random ?v= forced a re-download on every load)
        wp_register_script(
            $this->gateway_script,
            plugin_dir_url(__FILE__) . '../assets/js/blocks/' . $this->gateway->name . '.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            defined('WC_KASHIER_VERSION') ? WC_KASHIER_VERSION : null,
            true
        );

        if (function_exists('wp_set_script_translations')) {
            wp_set_script_translations($this->gateway_script);
        }

        // Always localize: if the params are missing (e.g. empty cart or the block editor) the script throws and the method never registers
        wp_localize_script($this->gateway_script, 'wc_'.$this->gateway->name.'_params', array(
            'baseurl'       => plugin_dir_url(__FILE__) . '../',
            'icons'         => $this->gateway->icons,
            // "bank_installments" => "Bank Installments"
            'title'         => !empty($this->gateway->block_title)
                ? $this->gateway->block_title
                : $this->get_block_title(),
            'description'   => $this->gateway->method_public_description,
            'id'            => $this->gateway->id
        ));

        return [$this->gateway_script];
    }
}
