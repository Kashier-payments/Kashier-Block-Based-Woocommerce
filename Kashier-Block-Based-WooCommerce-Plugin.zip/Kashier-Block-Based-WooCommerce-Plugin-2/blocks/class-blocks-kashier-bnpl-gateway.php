<?php
class Kashier_Gateway_Bnpl_Blocks extends Base_Gateway_Blocks {
    protected $gateway_script = 'kashier_gateway-bnpl-blocks-integration';
    protected $name = 'kashier_bnpl';
    protected function create_gateway_instance() {
        return new WC_Gateway_Kashier_Bnpl();
    }
}
