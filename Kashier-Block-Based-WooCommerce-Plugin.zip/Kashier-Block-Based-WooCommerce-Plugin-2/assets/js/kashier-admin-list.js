/**
 * Adds the provider logos under the "Buy Now, Pay Later" description in
 * WooCommerce > Settings > Payments. WooCommerce renders that page with React
 * and only supports a logo row for its own WooPayments, so we add ours to the
 * DOM and re-add it whenever React re-renders the list.
 */
(function () {
  var data = window.kashierBnplAdminList;
  if (!data || !data.logos || !data.logos.length) {
    return;
  }

  var ROW_ID = data.rowId || 'kashier_bnpl';
  var MARK = 'kashier-bnpl-admin-logos';

  function build() {
    var wrap = document.createElement('div');
    wrap.className = MARK;
    wrap.style.cssText =
      'display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin-top:10px;';

    data.logos.forEach(function (src) {
      var img = document.createElement('img');
      img.src = src;
      img.alt = '';
      img.style.cssText =
        'height:24px;width:auto;max-width:56px;object-fit:contain;' +
        'padding:4px 8px;box-sizing:content-box;background:#fff;' +
        'border:1px solid #e3e3e3;border-radius:4px;';
      wrap.appendChild(img);
    });

    return wrap;
  }

  function inject() {
    var row = document.getElementById(ROW_ID);
    if (!row || row.querySelector('.' + MARK)) {
      return;
    }
    var description = row.querySelector('.woocommerce-list__item-content');
    if (!description) {
      return;
    }
    description.insertAdjacentElement('afterend', build());
  }

  var scheduled = false;
  function schedule() {
    if (scheduled) {
      return;
    }
    scheduled = true;
    window.requestAnimationFrame(function () {
      scheduled = false;
      inject();
    });
  }

  inject();
  new MutationObserver(schedule).observe(document.body, {
    childList: true,
    subtree: true,
  });
})();
