jQuery(document).ready(function ($) {
  const id = $('#kashier-admin').attr('methodId');
  const advanced = $(`#woocommerce_${id}_advanced_options`);

  // Rows that only apply when "Advanced Options" is enabled (looked up by field id, not row position)
  const advancedRows = $(
    `#woocommerce_${id}_enforce_egp_payment, #woocommerce_${id}_connected_account`
  ).closest('tr');

  function toggleAdvanced() {
    if (advanced.is(':checked')) {
      advancedRows.show();
    } else {
      advancedRows.hide();
    }
  }

  toggleAdvanced();
  advanced.on('change', toggleAdvanced);
});
