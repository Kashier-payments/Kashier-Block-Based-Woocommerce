(function () {
    const params = wc_wallet_params;
    const name = 'kashier_wallet';
    const rawLabel = window.wp.htmlEntities.decodeEntities(params.title) || window.wp.i18n.__('Kashier', 'kasheir_gateway');
    const label = rawLabel.charAt(0).toUpperCase() + rawLabel.slice(1);

    // Updated Icon component to handle multiple icons
    const Icon = () => {
        const icons = params.icons || [];

        if (icons.length === 0) return null;

        return window.wp.element.createElement(
            'div',
            { style: { display: 'flex', justifyContent: 'flex-end' } },
            icons.map((icon, index) =>
                window.wp.element.createElement('img', {
                    src: params.baseurl + 'assets/images/' + icon,
                    id: `kashier-icon-${index}`,
                    style: {
                        maxWidth: '70px',
                        marginInlineStart: '10px',
                        paddingTop: '6px',
                    },
                    alt: `Kashier Icon ${index + 1}`
                })
            )
        );
    };

    const LabelWithIcon = () => {
        return window.wp.element.createElement('div', { style: { width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between' } }, label, window.wp.element.createElement(Icon));
    };

    // No description or "Secured by Kashier" badge
    const Content = () => null;

    const Block_Gateway =  {
        name,
        label: window.wp.element.createElement(LabelWithIcon),
        content: window.wp.element.createElement(Content, null),
        edit: window.wp.element.createElement(Content, null),
        canMakePayment: () => true,
        ariaLabel: label,
        supports: {
            features: params.supports,
        },
    };

    window.wc.wcBlocksRegistry.registerPaymentMethod(Block_Gateway);
})();
