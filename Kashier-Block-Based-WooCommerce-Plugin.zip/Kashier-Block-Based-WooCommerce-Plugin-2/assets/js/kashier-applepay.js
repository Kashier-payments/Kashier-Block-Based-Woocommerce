/**
 * Apple Pay pay page: loads Kashier's SDK, which renders the Apple Pay button
 * for the session created at Place order. The customer must tap that button
 * themselves (Apple only opens the payment sheet from a real user gesture).
 */
(function () {
  var cfg = window.kashierApplepay;
  if (!cfg) {
    return;
  }

  function showFailure(text) {
    var box = document.getElementById('kashier-failure-id');
    if (!box) {
      return;
    }
    box.innerHTML = '';
    var p = document.createElement('p');
    p.textContent = text;
    var a = document.createElement('a');
    a.className = 'button';
    a.href = cfg.checkoutUrl;
    a.textContent = cfg.i18n.retry;
    box.appendChild(p);
    box.appendChild(a);
  }

  function goToOrder() {
    window.location.href = cfg.returnUrl;
  }

  // Confirm with Kashier on the server, then show the order-received page.
  // Never mark the order paid from the browser alone.
  function verifyThenRedirect() {
    var body = new FormData();
    body.append('action', 'kashier_applepay_verify');
    body.append('order_id', cfg.orderId);
    body.append('key', cfg.orderKey);
    body.append('nonce', cfg.nonce);

    var done = false;
    function finish() {
      if (!done) {
        done = true;
        goToOrder();
      }
    }
    // Don't leave the customer waiting if the verification call is slow.
    setTimeout(finish, 6000);

    fetch(cfg.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' })
      .then(finish, finish);
  }

  function start() {

    if (!window.kashierSDK || typeof window.kashierSDK.load !== 'function') {
      showFailure(cfg.i18n.failed);
      return;
    }

    window.kashierSDK.load({
      data: { mode: cfg.mode, sessionId: cfg.sessionId },
      onSuccess: verifyThenRedirect,
      onFailure: function () {
        showFailure(cfg.i18n.failed);
      },
      locale: cfg.locale
    });

    // If the SDK shows no button (device/browser without Apple Pay), say so.
    setTimeout(function () {
      var holder = document.getElementById('kashier-sdk-id');
      if (holder && !holder.children.length && !window.ApplePaySession) {
        showFailure(cfg.i18n.unsupported);
      }
    }, 5000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
})();
