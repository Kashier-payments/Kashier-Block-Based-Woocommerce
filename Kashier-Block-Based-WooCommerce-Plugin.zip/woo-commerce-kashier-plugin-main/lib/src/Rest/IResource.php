<?php

namespace ITeam\Kashier\Rest;

/**
 * Interface IResource
 *
 * @package ITeam\Kashier\Rest
 */
interface IResource
{
}
