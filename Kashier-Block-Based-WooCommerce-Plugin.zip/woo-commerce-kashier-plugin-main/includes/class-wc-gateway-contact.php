<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Gateway_Kashier class.
 *
 * @extends WC_Payment_Gateway
 */
class WC_Gateway_Kashier_Contact extends Kashier_Gateway
{
     protected $_code = 'contact';
     public $name = 'contact now';
    public $icons = ['contact_now'];

    

}
